#ifndef TESTBENCH_H
#define TESTBENCH_H

#include "MemoryModel.h"

class Testbench {
public:
    void runTests();
};

#endif // TESTBENCH_H
